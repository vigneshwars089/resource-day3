﻿using System;
using System.Web;
using System.Web.Mvc;
using Quart.BusinessEntity;
using Quart.Utility;
using System.Runtime.InteropServices;
using Quart.BAL.Implementation;
using System.Configuration;
using System.Web.SessionState;
using System.Reflection;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace Quart.WebUI.Controllers
{
    /// <summary>
    /// Log on Controller Class 
    /// </summary>
    public class LogOnController : Controller
    {
        EntityConfiguration objBAL = new EntityConfiguration();
        private Logger ProxyLogger = new Logger();
        /// <summary>
        /// Method to Validate logon user
        /// </summary>
        /// <param name="lpszUsername"></param>
        /// <param name="lpszDomain"></param>
        /// <param name="lpszPassword"></param>
        /// <param name="dwLogonType"></param>
        /// <param name="dwLogonProvider"></param>
        /// <param name="phToken"></param>
        /// <returns></returns>
        [DllImport("ADVAPI32.dll", EntryPoint = "LogonUserW", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        [DllImport("kernel32.dll")]
        private static extern int FormatMessage(int dwFlags, string lpSource, int dwMessageId, int dwLanguageId, StringBuilder lpBuffer, int nSize, string[] Arguments);
        ////
        // GET: /LogOn/

        #region *************Login & LogOut Methods**********

        /// <summary>
        /// Method to Load Default Login View 
        /// </summary>
        /// <returns>ActionResult</returns>
        public ActionResult Login(string Tenant)
        {
            ProxyLogger.Log.Info("LogOnController - Login - Called.");
            try
            {                
                List<Quart.BusinessEntity.TenantEntity> lstTenantDetail = null;
                Quart.BusinessEntity.BaseTransportEntity _objbase = new Quart.BusinessEntity.BaseTransportEntity();
                TenantEntity _ObjTnt = new TenantEntity();
                _ObjTnt.level = 3;
                _ObjTnt.TenantName = Tenant;
                _objbase = (Quart.BusinessEntity.BaseTransportEntity)_ObjTnt;
                lstTenantDetail = objBAL.GetEntityList(_objbase).Cast<Quart.BusinessEntity.TenantEntity>().ToList();
               
                Session["TENANTID"]=lstTenantDetail[0].TenantId.ToString();

                if (Session["SYSUSERID"] != null)
                {
                    ProxyLogger.Log.Error("Clearing/Abandon Session on Login");
                    Session.Clear();
                    Session.Abandon();
                    Session.RemoveAll();
                }
            }
            catch (NotImplementedException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return View();
        }


        /// <summary>
        /// Method to Authenticate User Provide Window Credentials
        /// </summary>
        /// <param name="userName">string</param>
        /// <param name="password">string</param>
        /// <param name="domain">string</param>
        /// <param name="browserName">string</param>
        /// <param name="version">string</param>
        /// <param name="browserMode">string</param>
        /// <param name="documentMode">string</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult AuthenticateWindowsCreds(string userName, string password, string domain, string browserName, string version, string browserMode, string documentMode)
        {
            ProxyLogger.Log.Info("LogOnController - AuthenticateWindowsCreds - Called.");

            string valid = null;

            try
            {
                string ciphertext = System.Configuration.ConfigurationManager.AppSettings[Constants.CIPHERPASSWORD];
                string LoginEncrypt = System.Configuration.ConfigurationManager.AppSettings["LoginEncrypt"];

                if (!string.IsNullOrWhiteSpace(LoginEncrypt) && LoginEncrypt == "1")
                {
                    userName = EncodeDecode.LoginStringDecode(userName, ciphertext);
                    password = EncodeDecode.LoginStringDecode(password, ciphertext);
                }

                string domainName = GetDomainName(userName); // Extract domain name 

                //form provide DomainUsername e.g Domainname\Username
                string userid = GetUsername(userName);  // Extract user name 

                bool result = false;
                if (!string.IsNullOrEmpty(userid))
                {
                    //from provided DomainUsername e.g Domainname\Username
                    IntPtr token = IntPtr.Zero;
                    result = LogonUser(userid, domainName, password, 3, 0, ref token);
                }
                else
                {
                    ProxyLogger.Log.Error("Error on getting userid && domain name " + userName);
                }

                if (result)
                {
                    valid = "Successful";
                }
                else
                {
                    valid = "UnSuccessful";

                    //To get the exact login error
                    int apiError = Marshal.GetLastWin32Error();
                    StringBuilder errorMessage = new StringBuilder(1024);
                    FormatMessage(0x1000, null, apiError, 0, errorMessage, 1024, null);
                    throw new Exception(errorMessage.ToString());
                }

                if (valid == "Successful")
                {
                    if (GetUserDetails(userid, browserName, version, browserMode, documentMode, "Login"))
                    {
                        valid = "1";//success
                    }
                    else
                    {
                        valid = "2";//unauthorized user
                    }
                }
                else if (valid == "UnSuccessful")
                {
                    valid = "3";//failure
                }
            }
            catch (ConfigurationErrorsException Ex)
            {
                valid = "3";//failure
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                valid = "3";//failure
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                valid = "3";//failure
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }

            return Json(new { valid = valid }, JsonRequestBehavior.AllowGet);

        }

        /// <summary>
        /// Method to Get Default Login View 
        /// </summary>
        /// <returns>ActionResult</returns>
        public ActionResult Logout()
        {
            return View("Login");
        }

        /// <summary>
        /// Method to Clear and Abandon Session Variables
        /// </summary>
        /// <returns>JsonResult</returns>
        [HttpGet]
        public JsonResult LogoutComplete()
        {
            ProxyLogger.Log.Info("LogOnController - LogoutComplete - Called.");

            try
            {
                BaseTransportEntity objBase = new BaseTransportEntity();
                LoginEntity objLogin = new LoginEntity();
                if (Session["SYSUSERID"] != null)
                {
                    objLogin.systemUserId = Convert.ToInt32(Session["SYSUSERID"]);
                    objBase = (BaseTransportEntity)objLogin;
                    string result = objBAL.SetEntity(objBase);
                }
                else
                {
                    objLogin.systemUserId = 0;
                }

                Session.Clear();
                Session.Abandon();
            }
            catch (FormatException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (InvalidCastException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (OverflowException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (NotImplementedException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return Json(new { redirectToUrl = Url.Action("Login", "Logon") }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to Get  Valide User Details
        /// </summary>
        /// <param name="userId">string</param>
        /// <param name="browserName">string</param>
        /// <param name="version">string</param>
        /// <param name="browserMode">string</param>
        /// <param name="documentMode">string</param>
        /// <param name="loginMode">string</param>
        /// <returns>bool</returns>
        protected bool GetUserDetails(string userId, string browserName, string version, string browserMode, string documentMode, string loginMode)
        {
            ProxyLogger.Log.Info("LogOnController - GetUserDetails - Called.");

            bool retval = false;

            BaseTransportEntity objBase = new BaseTransportEntity();
            LoginEntity newLogin = new LoginEntity();

            try
            {
                newLogin.userId = userId;
                newLogin.browserName = browserName;
                newLogin.version = version;
                newLogin.browserMode = browserMode;
                newLogin.documentMode = documentMode;
                newLogin.loginMode = loginMode;
                Session["CurrentDT"] = DateTime.Now;

                log4net.Config.XmlConfigurator.Configure();
                log4net.GlobalContext.Properties["login"] = userId;
                log4net.ThreadContext.Properties["login"] = userId;
                log4net.Config.XmlConfigurator.Configure();

                objBase = (BaseTransportEntity)newLogin;
                newLogin = (LoginEntity)objBAL.GetEntity(objBase);

                if (newLogin.systemUserId.ToString() != "0")
                {
                    retval = true;
                    Session["CTSUSERID"] = userId;
                    Session["SYSUSERID"] = newLogin.systemUserId;
                    Session["SYSUSERName"] = newLogin.UserName;
                    string ClientName = System.Configuration.ConfigurationManager.AppSettings["ClientName"];
                    Session["ClientName"] = ClientName;
                    Session["ConsolidatedReportId"] = System.Configuration.ConfigurationManager.AppSettings["ConsolidatedReportId"];
                    Session["CalibratorReportId"] = System.Configuration.ConfigurationManager.AppSettings["CalibratorReportId"];
                    Session["VarianceReportId"] = System.Configuration.ConfigurationManager.AppSettings["VarianceReportId"];
                }
                else
                {
                    retval = false;

                }
            }
            catch (ConfigurationErrorsException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            finally
            {
                if (objBase != null)
                    objBase = null;

                if (newLogin != null)
                    newLogin = null;
            }
            return retval;
        }
        /// <summary>
        /// Method to Get Domain name
        /// </summary>
        /// <param name="usernameDomain"></param>
        /// <returns></returns>
        public string GetDomainName(string usernameDomain)
        {
            ProxyLogger.Log.Info("LogOnController - GetDomainName - Called.");

            string _domainName = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(usernameDomain))
                {
                    throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
                }
                if (usernameDomain.Contains("\\"))
                {
                    int index = usernameDomain.IndexOf("\\");
                    _domainName = usernameDomain.Substring(0, index);
                }
                else if (usernameDomain.Contains("@"))
                {
                    int index = usernameDomain.IndexOf("@");
                    _domainName = usernameDomain.Substring(index + 1);
                }
                else
                {
                    _domainName = "";
                }
            }
            catch (ArgumentException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return _domainName;
        }

        /// <summary>
        /// Method to Parses the string to pull the user name out.
        /// </summary>
        /// <param name="usernameDomain">The string to parse that must contain the username in either the domain\username or UPN format username@domain</param>
        /// <returns>The username or the string if no domain is found.</returns>
        public string GetUsername(string usernameDomain)
        {
            ProxyLogger.Log.Info("LogOnController - GetUsername - Called.");

            string _userName = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(usernameDomain))
                {
                    throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
                }
                if (usernameDomain.Contains("\\"))
                {
                    int index = usernameDomain.IndexOf("\\");
                    _userName = usernameDomain.Substring(index + 1);
                }
                else if (usernameDomain.Contains("@"))
                {
                    int index = usernameDomain.IndexOf("@");
                    _userName = usernameDomain.Substring(0, index);
                }
                else
                {
                    _userName = usernameDomain;
                }
            }
            catch (ArgumentException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return _userName;
        }

        /// <summary>
        /// Method to Validate static logon 
        /// </summary>
        /// <param name="UserId">string</param>
        /// <param name="Password">string</param>
        /// <param name="browserName">string</param>
        /// <param name="version">string</param>
        /// <param name="browserMode">string</param>
        /// <param name="documentMode">string</param>
        /// <returns>ActionResult</returns>
        public ActionResult StaticLogin(string UserId, string Password, string browserName, string version, string browserMode, string documentMode)
        {
            ProxyLogger.Log.Info("LogOnController - StaticLogin - Called.");

            try
            {
                string id;
                System.Web.UI.Page page = new System.Web.UI.Page();
                string password1 = Convert.ToString(ConfigurationManager.AppSettings["Pwd"]);
                if (Password == password1)
                {
                    id = UserId;
                    if (GetUserDetails(id, browserName, version, browserMode, documentMode, "Static"))
                    {
                        return Json(new { redirectToUrl = Url.Action("../ChangeRole/Home") });
                    }
                    else
                    {
                        return Json(new { redirectToUrl = Url.Action("../Logon/_UnAuthorizedUser") });
                    }
                }
            }
            catch (ConfigurationErrorsException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }

            return Json(new { redirectToUrl = Url.Action("../StaticLogOn/Index") });
        }

        #endregion

        #region *************Session Methods**********

        /// <summary>
        /// Method to Load Session Expired Information to User
        /// </summary>
        /// <returns>ActionResult</returns>
        public ActionResult SessionExpired()
        {
            return View();
        }
        /// <summary>
        /// Method to Load Help View 
        /// </summary>
        /// <returns></returns>
        public ActionResult Help()
        {
            return View("Help");
        }

        /// <summary>
        /// Method to Redirect to session expired Information View
        /// </summary>
        /// <returns>JsonResult</returns>
        [HttpGet]
        public JsonResult RedirectToSessionExpired()
        {
            return Json(new { redirectToUrl = Url.Action("Sessionexpired", "Logon") }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to Redirect to login View 
        /// </summary>
        /// <returns>JsonResult</returns>
        [HttpGet]
        public JsonResult RedirectToLogin()
        {
            BaseTransportEntity objBase = new BaseTransportEntity();
            LoginEntity objLogin = new LoginEntity();
            if ((Session["SYSUSERID"] != null) && (Session["RoleID"] != null))
            {
                return Json(new { redirectToUrl = Url.Action("../Dashboard/Home") }, JsonRequestBehavior.AllowGet);
            }
            else if ((Session["SYSUSERID"] != null) && (Session["RoleID"] == null))
            {
                return Json(new { redirectToUrl = Url.Action("../ChangeRole/Home") }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { redirectToUrl = Url.Action("../Logon/Login") }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Method to Check Session Expired and Update logout to DB
        /// </summary>
        /// <param name="systemUserId"></param>
        /// <returns>bool</returns>
        [HttpGet]
        public bool CheckSessionExpiredAndUpdateLogOutToDB(string systemUserId)
        {
            ProxyLogger.Log.Info("LogOnController - CheckSessionExpiredAndUpdateLogOutToDB - Called.");

            var rturn = false;
            BaseTransportEntity objBase = new BaseTransportEntity();
            LoginEntity objLogin = new LoginEntity();
            try
            {
                if (Session["SYSUSERID"] == null)
                {
                    if (!string.IsNullOrWhiteSpace(systemUserId))
                    {
                        objLogin.systemUserId = Convert.ToInt32(systemUserId);
                        objBase = (BaseTransportEntity)objLogin;
                        objBAL.SetEntity(objBase);
                    }
                    rturn = true;
                }
            }
            catch (FormatException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (OverflowException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            finally
            {
                if (objBase != null)
                    objBase = null;
                if (objLogin != null)
                    objLogin = null;
            }

            return rturn;
        }

        /// <summary>
        /// Method to Regenerate Session ID
        /// </summary>
        [HttpPost]
        public void ReGenerateId()
        {
            ProxyLogger.Log.Info("LogOnController - ReGenerateId - Called.");
            try
            {
                System.Web.SessionState.SessionIDManager manager = new System.Web.SessionState.SessionIDManager();
                string oldId = manager.GetSessionID(System.Web.HttpContext.Current);
                string newId = manager.CreateSessionID(System.Web.HttpContext.Current);

                bool isAdd = false, isRedir = false;
                manager.SaveSessionID(System.Web.HttpContext.Current, newId, out isRedir, out isAdd);
                HttpApplication ctx = (HttpApplication)System.Web.HttpContext.Current.ApplicationInstance;
                HttpModuleCollection mods = ctx.Modules;
                System.Web.SessionState.SessionStateModule ssm = (SessionStateModule)mods.Get("Session");
                System.Reflection.FieldInfo[] fields = ssm.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                SessionStateStoreProviderBase store = null;
                System.Reflection.FieldInfo rqIdField = null, rqLockIdField = null, rqStateNotFoundField = null;
                foreach (System.Reflection.FieldInfo field in fields)
                {
                    if (field.Name.Equals("_store")) store = (SessionStateStoreProviderBase)field.GetValue(ssm);
                    if (field.Name.Equals("_rqId")) rqIdField = field;
                    if (field.Name.Equals("_rqLockId")) rqLockIdField = field;
                    if (field.Name.Equals("_rqSessionStateNotFound")) rqStateNotFoundField = field;
                }
                object lockId = rqLockIdField.GetValue(ssm);
                if ((lockId != null) && (oldId != null)) store.ReleaseItemExclusive(System.Web.HttpContext.Current, oldId, lockId);
                rqStateNotFoundField.SetValue(ssm, true);
                rqIdField.SetValue(ssm, newId);
            }
            catch (FieldAccessException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (TargetException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ArgumentException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (ApplicationException Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)
            {
                ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }

        }


        #endregion

        #region *************Error Related Methods**********
        /// <summary>
        /// Method to  Get Error
        /// </summary>
        /// <returns></returns>
        public ActionResult Error()
        {
            return View();
        }

        /// <summary>
        /// Method to Show Unauthorized User Message
        /// </summary>
        /// <returns></returns>
        public ActionResult _UnAuthorizedUser()
        {
            return View();
        }
        /// <summary>
        /// Method to Show Expired Session Expired page
        /// </summary>
        /// <returns></returns>
        public ActionResult ExpiredPage()
        {
            return View();
        }

        #endregion

    }
}
